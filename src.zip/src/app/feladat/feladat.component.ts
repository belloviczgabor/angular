import { Component } from '@angular/core';

@Component({
  selector: 'app-feladat',
  templateUrl: './feladat.component.html',
  styleUrl: './feladat.component.css'
})
export class FeladatComponent {

  szam!: number

  megoldasok: string[] = [];


  SzamKiolvasas() {
    return this.szam
  }

  EredmenyMentes() {
    let oszto = 0;
    for (let i = 1; i <= this.SzamKiolvasas(); i++) {
      if (this.SzamKiolvasas() % i == 0) {
        oszto++;
      }
    }
    if (oszto == 2) {
      this.megoldasok.push(`Az ${this.SzamKiolvasas()} prim`)
    }
    else {
      this.megoldasok.push(`Az ${this.SzamKiolvasas()}  NEM prim`)
    }
  }


}
