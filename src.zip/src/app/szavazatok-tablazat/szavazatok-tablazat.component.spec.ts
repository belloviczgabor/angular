import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SzavazatokTablazatComponent } from './szavazatok-tablazat.component';

describe('SzavazatokTablazatComponent', () => {
  let component: SzavazatokTablazatComponent;
  let fixture: ComponentFixture<SzavazatokTablazatComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [SzavazatokTablazatComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SzavazatokTablazatComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
